import java.io.PrintWriter;
import java.util.Scanner;

public class QuestionsGame {

	private QuestionNode overallRoot;
	private static Scanner console;
	
	public QuestionsGame(String object) {
		
	}
	
	public QuestionsGame(Scanner fileIn) {
		 
	   

	}
	
	// QuestionsGame(Scanner fileIn) recursive helper method
	private QuestionNode readTree(Scanner input) {

		return null;
	}
	
	
	public void saveQuestions(PrintWriter fileOut) {
	
	}
	
	// saveQuestions recursive helper method
	private void writeTree(PrintWriter output, QuestionNode root) {
		
	}
	

	public void play() {
	
	}
	
	// play recursive helper method
    private QuestionNode play(QuestionNode root) {
 
        return root;
    }

	
}
